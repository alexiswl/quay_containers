#!/usr/bin/env python

from distutils.core import setup
import setuptools
import sys

with open('requirements.txt') as f:
    required = f.read().splitlines()

if sys.version_info.major < 3:
    sys.exit("Error, python3.5 or higher is required.")

if sys.version_info.minor < 5:
    sys.exit("Error, python3.5 or higher is required")

setup(name='slurm_tools',
      version='1.0',
      description='Control slurm from within python',
      author='Alexis Lucattini',
      author_email='alexis.lucattini@agrf.org.au',
      url='',
      packages=['slurm'],
      install_requires=required
     )