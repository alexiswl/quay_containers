#!/usr/bin/env python3

"""
Given a scheduler log directory with log files as the  following format
slurm-130589.out where 130589 is the job ID.
"""

from slurm import slurm
import re
import numpy as np
import matplotlib
matplotlib.use('agg')
from matplotlib import pyplot as plt
from matplotlib.pylab import savefig
import humanfriendly
import numpy
from matplotlib.ticker import FuncFormatter, PercentFormatter
import os
import argparse

COLUMNS = ["JobID", "JobName%30", "MaxRSS", "AveRSS", "ReqMem", "AveCPU",
           "Elapsed", "ExitCode", "NodeList", "State", "Submit", "Start", "Time"]
BYTES_PER_KB = pow(2, 10)


class Job:
    def __init__(self, job):
        self.id = job

def mem_to_int(mem_int): 
    mem_int = re.sub("n$", "", mem_int)
    if mem_int is None or mem_int == "" or mem_int == '0':
        return 0
    try: 
        int_component, unit_component = re.match("^(\d+)(\w+)", mem_int).group(1, 2) 
        int_component = int(int_component)
        if unit_component == 'M':
            int_component = int_component * pow(2, 20)
        elif unit_component == 'G':
            int_component = int_component * pow(2, 30)
        elif unit_component == "K":
            int_component = int_component * pow(2, 10)
        return int_component
    except AttributeError:
        print(mem_int)
    print(mem_int)
        

def get_args():
    parser = argparse.ArgumentParser(description="Show metrics of pipeline")
    parser.add_argument("--plots_dir", type=str, required=True,
                        help="Path to output plots")
    parser.add_argument("--scheduler_dir", type=str, required=True,
                        help="Path to list of slurm output")
    parser.add_argument("--prefix", type=str, required=True,
                        help="Prefix for plots")
    return parser.parse_args()


def get_jobs(scheduler_path):
    slurm_ids = list([Job(re.match("^slurm-(\d+).out$", slurm_file).group(1))
                          for slurm_file in os.listdir(scheduler_path)
                          if slurm_file.startswith("slurm")
                          and slurm_file.endswith(".out")]) 
    return slurm_ids


def get_df(slurm_ids):
    # Get slurm acct using globally defined columns
    slurm_df = slurm.slurm_to_pd(slurm_ids, columns=COLUMNS)
    # Strip jobname column 
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: x.strip())
    # Exome jobs
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: x.split("_")[0] 
                                                           if x.startswith("align") 
                                                           or x.startswith("mergeandmark") 
                                                           or x.startswith("genomicsdbimport")
                                                           or x.startswith("Rscript") 
                                                           or x.startswith("genotypevcfsbycontig") else x)
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: "splitvariants" 
                                                           if x.startswith("splitvariants")
                                                           else x)
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: "genotypevcfsbycontig"
                                                            if x.startswith("genotypevcfsbycontig")
                                                            else x)
    # Demultiplex jobs
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: "fastqc"
                                                            if x.startswith("fastqc")
                                                            else x)
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: "blast"
                                                            if x.startswith("blast")
                                                            else x)
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: "multiqc"
                                                            if x.startswith("multiqc")
                                                            else x)





    # Convert memory to integer
    print("Working MAXRSS")
    slurm_df['MaxRSS'] = slurm_df['MaxRSS'].apply(lambda x: mem_to_int(x))
    print("Working ReqMem")
    slurm_df['ReqMem'] = slurm_df['ReqMem'].apply(lambda x: mem_to_int(x))
    # Convert AveRSS
 
    return slurm_df


def mem_hist_to_human_readable(x, position):
    # Convert from 1234K to 1.2 Mb: 
    if x == 0:
        return 0
    s = humanfriendly.format_size(x, binary=True)
    return s


def plot_mem(slurm_df, output_file):
    # Plot a histogram of the memory usage used by all the jobs.
    slurm_mem_max = slurm_df['MaxRSS']
    slurm_mem_av = slurm_df['AveRSS']
    req_mem_line = slurm_df['ReqMem'].max()
    # Configure bins
    num_bins = 50
    bins = np.linspace(start=0, stop=max(slurm_mem_max.max(), req_mem_line), num=num_bins)
    bin_width = bins[1] - bins[0]
    plt.close('all')
    fig, ax = plt.subplots(1, figsize=(8,8))
    # Plot histogram
    slurm_mem_max.plot(kind="hist", ax=ax, bins=bins, alpha=0.6)
    # Add x axis labels
    ax.set_xlabel("Memory Usage")
    ax.xaxis.set_major_formatter(FuncFormatter(mem_hist_to_human_readable))
    # Modify yaxis labels and ticks
    ax.set_ylabel("Number of Jobs in bin")
    #def y_hist_to_numbers(y, position):
    #    y = y / slurm_mem_max.sum()
    #    return y
    #ax.yaxis.set_major_formatter(PercentFormatter(xmax=1))
    #ax.get_yaxis().set_visible(False)
    # Add title
    if len(slurm_df["JobName"].unique().tolist()) > 1:
        ax.set_title("Max Memory Usage Histogram (all jobs)")
    else:
        ax.set_title("Max Memory Usage for job %s" % slurm_df["JobName"].unique().item())
    # Plot Reqmem line
    ax.axvline(linewidth=4, color='r', x=req_mem_line)
    # Render plot
    fig.tight_layout()
    # Save to file
    savefig(output_file)
    plt.close('all')


def plot_mem_by_job(slurm_df, plots_dir, prefix):
    for job_name in slurm_df["JobName"].unique().tolist():
        if len(slurm_df.query("JobName=='%s'" % job_name).index.tolist()) <= 1:
            # Just one job, we're not plotting this
            continue
        output_file = os.path.join(plots_dir, '.'.join([prefix, "max_memory_usage_by_job.%s.png" % job_name]))
        plot_mem(slurm_df.query("JobName=='%s'" % job_name), output_file)




def main():
    # Get arguments and job list
    print("Getting arguments and jobs")
    args = get_args()
    jobs = get_jobs(args.scheduler_dir)
    slurm_df = get_df(jobs)
    # Create required directories
    if not os.path.isdir(args.plots_dir):
        os.mkdir(args.plots_dir, mode=0o775)
    print("Plotting all memory jobs")
    # Plot memory.
    plot_mem(slurm_df, os.path.join(args.plots_dir, '.'.join([args.prefix, "all_mem.png"])))
    print("Plotting individual stages")
    plot_mem_by_job(slurm_df, args.plots_dir, args.prefix)
    slurm_df.to_csv(os.path.join(args.plots_dir, args.prefix+".tsv"), sep="\t", 
                    index=False, header=True)

if __name__ == "__main__":
    main()
