#!/usr/bin/env python3

# Import args
import argparse
from slurm import slurm
import matplotlib
import pandas as pd
from matplotlib import pyplot as plt
import logging
import sys
import humanfriendly
import math
from matplotlib.ticker import FuncFormatter
import re
import numpy as np
import seaborn as sns
import subprocess
import os
import pickle

# Globals
total_cpus = sum([2*2*18*2, 2*4*10*2, 3*4*16*2, 2*8*2])
total_memory = sum([2*128000, 2*512000, 3*1536000, 2*128000]) * 1000000
standard_job_columns = ['JobID', 'JobIDRaw', 'JobName', 'ReqMem', 'NCPUS', 'MaxRSS',
                        'Timelimit', 'Elapsed', 'Submit', 'Start', 'End',
                        'TotalCPU', 'SystemCPU', 'CPUTimeRAW', 'wckey', 'NodeList', 'NNodes']
"""
balder]$ grep -i sockets /etc/slurm/slurm.conf
NodeName=bioweb02 RealMemory=1 Sockets=1 CoresPerSocket=1 ThreadsPerCore=1 State=UNKNOWN
NodeName=bioweb04 RealMemory=1 Sockets=1 CoresPerSocket=1 ThreadsPerCore=1 State=UNKNOWN
NodeName=balder-wn[01-02] RealMemory=128000 Sockets=2 CoresPerSocket=18 ThreadsPerCore=2 State=UNKNOWN
NodeName=balder-wn[03,07] RealMemory=512000 Sockets=4 CoresPerSocket=10 ThreadsPerCore=2 State=UNKNOWN
NodeName=balder-wn[04-06] RealMemory=1536000 Sockets=4 CoresPerSocket=16 ThreadsPerCore=2 State=UNKNOWN
NodeName=balder-wn08 RealMemory=128000 Sockets=2 CoresPerSocket=8 ThreadsPerCore=2 State=UNKNOWN
NodeName=balder-wntest RealMemory=15000 Sockets=2 CoresPerSocket=4 ThreadsPerCore=1 State=UNKNOWN
"""

sockets_by_node = {"balder-wn01": 2,
                   "balder-wn02": 2,
                   "balder-wn03": 2,
                   "balder-wn04": 2,
                   "balder-wn05": 2,
                   "balder-wn06": 2,
                   "balder-wn07": 2,
                   "balder-wn08": 2}

# CMAP needs to be converted to RBG code to work
def int_to_hex(my_int):
    return format(int(255*my_int), '02x')


def colours_to_rgb(red, blue, green):
    return '#%s%s%s' % (int_to_hex(red), int_to_hex(blue), int_to_hex(green))


# Get enough colours to plot on both shaded and unshaded
colours = list(plt.cm.tab10.colors) #+ list(reversed(plt.cm.Set3.colors))
my_rbg = [colours_to_rgb(*colour) for colour in colours]


# Job class
class Job:
    def __init__(self, slurm_id):
        self.id = slurm_id


# Formatting functions
def parse_number(value_h):
    return int(re.match("^(\d+)\S+$", value_h).group(1))


def convert_human_to_int(value_h):
    if value_h.endswith("G"):
        value = parse_number(value_h) * 1000000000
    elif value_h.endswith("M"):
        value = parse_number(value_h) * 1000000
    elif value_h.endswith("K"):
        value = parse_number(value_h) * 1000
    elif value_h == "":
        value = 0
    else:
        value = int(value_h)
    return int(value)


def convert_reqmem_to_int(value_h, ncpus, nodes):
    if value_h.endswith("n"):    
        if value_h.endswith("Gn"):
            value = parse_number(value_h) * 1000000000
        elif value_h.endswith("Mn"):
            value = parse_number(value_h) * 1000000
        elif value_h.endswith("Kn"):
            value = parse_number(value_h) * 1000
        else:
            value = parse_number(value_h)
        value = value * nodes
    elif value_h.endswith("c"):
        if value_h.endswith("Gc"):
            value = parse_number(value_h) * 1000000000
        elif value_h.endswith("Mc"):
            value = parse_number(value_h) * 1000000
        elif value_h.endswith("Kc"):
            value = parse_number(value_h) * 1000
        else:
            value = parse_number(value_h) 
        value = value * ncpus
    else:
        value = int(value_h)
    return int(value)
 

def convert_int_to_human_formatter(value, pos):
    return humanfriendly.format_size(value).replace("bytes", "")


def convert_seconds_to_hh_mm_formatter(value, pos):
    hours = math.floor(value / 3600)
    minutes = (value - 3600 * hours) / 60
    return "%02d:%02d" % (hours, minutes)


def convert_time_format(time_str):
    days = 0
    microseconds = 0
    if '-' in time_str:
        # We have days 
        days, hms = time_str.split('-', 1)
    elif '.' in time_str and time_str.count(":") == 2:
        # We have microsecnds
        hms, microseconds = time_str.split(".", 1)
    elif '.' in time_str and time_str.count(":") == 1:
        hms, microseconds = time_str.split(".", 1)
        hms = "00:%s" % hms
    else:
        # Hours only
        hms = time_str

    try:
        time_str = '%d days %s.%06d' % (int(days), hms, int(microseconds))
    except TypeError:
        print(time_str, days, hms, microseconds)
        raise TypeError

    return time_str


# Grab arguments
def get_args():
    """
    Obtain arguments from cli
    :return: args
    """

    parser = argparse.ArgumentParser(description='Generate a report from running of a pipeline')
    jobs_parser = parser.add_mutually_exclusive_group(required=True)
    jobs_parser.add_argument('--wckey', type=str, default=None,
                             help="Specify the wckey used by the pipeline to retrieve all relevant jobs.")
    jobs_parser.add_argument('--jobs', type=str,
                             help="Specify the jobs used by the pipeline. ',' separated for each job.")
    parser.add_argument('--output-prefix', type=str, default='pipeline_slurm', required=True,
                        help="Specify the prefix used for the html and the plotting images and pickle output")
    parser.add_argument("--precision", type=str, choices=['1min', '10min', '1H'], default='10min',
                        help='Space between plotting intervals, 1 min is most accurate but much slower')
    options_parser = parser.add_mutually_exclusive_group(required=False)
    options_parser.add_argument('--job-type', type=str, choices=['demux', 'rnaseq', 'exome'], required=False,
                                help='Used to better describe each of the stages')
    options_parser.add_argument("--sep-to-split", type=str, choices=['-', '_', 'r-', 'r_'], required=False,
                                help='Group jobs by splitting job name on separator. r for last value')
    parser.add_argument("--user", type=str, required=False, default='nextgenpipeline', 
                        help='Who ran the pipeline? Default is nextgenpipeline')

    return parser.parse_args()


# Grab df
def get_jobs(wckey=None, jobs=None, precision=None, user=None):
    """
    Using the wckey, grab all jobs that used this wckey
    :param wckey: something like child_of_123456
    :return:
    """
    if wckey is not None:
        sacct_command = ['sacct', '--wckey=%s' % wckey, '--parsable2', '--format', 'JobID',
                         '--allocations', '--noheader', '--user=%s' % user]
    elif jobs is not None: 
        sacct_command = ['sacct', '--jobs=%s' % jobs, '--parsable2', '--format', 'JobID',
                         '--allocations', '--noheader', '--user=%s' % user]
    else:
        sys.exit("Neither job or wckey was specified")
    sacct_proc = subprocess.run(sacct_command, timeout=100, capture_output=True)
    # Create jobs as a list of Object Job
    jobs = [Job(job.strip()) for job in sacct_proc.stdout.decode().splitlines()] 

    # Create slurm dataframe 
    print([job.id for job in jobs])
    slurm_df = slurm.slurm_to_pd(jobs, columns=standard_job_columns) 

    # Convert column names #
    # Rename TotalCPU to TotalCPURAW so it may be re-run without issue
    slurm_df.rename(columns={'TotalCPU': 'TotalCPURAW'}, inplace=True) 

    # Reset job column types
    slurm_df['JobID'] = slurm_df['JobIDRaw']
    slurm_df['NNodes'] = pd.to_numeric(slurm_df['NNodes'])
    slurm_df['SubmitRaw'] = pd.to_datetime(slurm_df['Submit'])
    slurm_df['StartRaw'] = pd.to_datetime(slurm_df['Start'])
    slurm_df['EndRaw'] = pd.to_datetime(slurm_df['End'], errors='coerce')
    slurm_df['WaitTime'] = slurm_df.apply(lambda x: x.StartRaw - x.SubmitRaw, axis='columns')
    # Remove Running Jobs
    slurm_df.dropna(inplace=True)
    slurm_df['NCPUS'] = pd.to_numeric(slurm_df['NCPUS'])
    slurm_df['Start'] = slurm_df['StartRaw'].dt.to_period(precision)
    slurm_df['End'] = slurm_df['EndRaw'].dt.to_period(precision)
    slurm_df['Submit'] = slurm_df['SubmitRaw'].dt.to_period(precision)
    slurm_df['StartRounded'] = slurm_df["Start"].apply(lambda x: x.to_timestamp())
    slurm_df['EndRounded'] = slurm_df['End'].apply(lambda x: x.to_timestamp())
    # Rename Mem and MaxRSS
    # Get Memory from ReqMem and MaxRSS

    slurm_df["ReqMemInt"] = slurm_df[['ReqMem', 'NCPUS', 'NNodes']].apply(lambda x: convert_reqmem_to_int(x.ReqMem, x.NCPUS, x.NNodes),
                                                                    axis='columns')
        
    slurm_df['MaxRSSInt'] = slurm_df[['MaxRSS', 'NCPUS']].apply(lambda x: convert_human_to_int(x.MaxRSS),
                                                                axis='columns')
    # Get CPUload values 
    slurm_df['Elapsed'] = pd.to_timedelta(slurm_df['Elapsed'].apply(lambda x: convert_time_format(x))) 
    slurm_df['SystemCPU'] = pd.to_timedelta(slurm_df['SystemCPU'].apply(lambda x: convert_time_format(x)))
    slurm_df["CPUTime"] = pd.to_timedelta(slurm_df["CPUTimeRAW"].apply(int), unit='seconds')
    slurm_df["CPULoad"] = slurm_df.apply(
            lambda x: x.SystemCPU.total_seconds() / (x.Elapsed.total_seconds() * sockets_by_node[x.NodeList] + 1), axis='columns')
     
    # Return slurm_df
    print(slurm_df[['Elapsed', 'CPUTime', 'SystemCPU', 'CPULoad']])
    return slurm_df


# Adjust job names
def adjust_exome_job_names(slurm_df):
    # Drop batch
    slurm_df.query("~JobName.str.contains('_batch')", inplace=True)
    # Change jobnames
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: "genotypevcfsbycontig" if x.JobName.startswith('genotypevcfsbyconti') else x.JobName, axis='columns')
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: x.JobName.rsplit("_", 1)[-1] if x.JobName.startswith('align') else x.JobName, axis='columns')
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: "splitvariants" if x.JobName.startswith("splitvariants") else x.JobName, axis='columns')
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: "genomicsdbimport" if x.JobName.split("_")[0] == 'genomicsdbimport' else x.JobName, axis='columns')
    slurm_df['JobName'] = slurm_df.apply(lambda x: "Rscript" if x.JobName.split("_")[0] == 'Rscript' else x.JobName,
                                         axis='columns')
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: "mergeandmark" if x.JobName.startswith("mergeandmark") else x.JobName, axis='columns')
    slurm_df['JobName'] = slurm_df.apply(lambda x: "md5sum" if x.JobName.startswith("slurm") else x.JobName,
                                         axis='columns')
    slurm_df['JobName'] = slurm_df.apply(lambda x: x.JobName.split("_", 1)[0], axis='columns')

    return slurm_df


def adjust_demux_job_names(slurm_df):
    # Drop batch
    slurm_df.query("~JobName.str.contains('_batch')", inplace=True)
    
    # Change job names
    # Shrink to first '_'
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: 'fastqc' if x.JobName.startswith("fastqc") else x.JobName, axis='columns')
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: x.JobName.split("_", 1)[0], axis='columns')

    # Change blast
    slurm_df['JobName'] = slurm_df.apply(
        lambda x: 'blast' if x.JobName.startswith("blast") else x.JobName, axis='columns')

    return slurm_df

 
# Specify overtime
def get_minute_dfs(slurm_df, precision):
    index_minute_periods = pd.period_range(start=slurm_df['Submit'].min(), end=slurm_df['End'].max(),
                                           freq=precision).tolist()
    minute_dfs = pd.DataFrame(data=None,
                              columns=['Minute', 'NumJobs', 'NCPUS', 'CPULoad',
                                       'ReqMemory', 'MaxMemory', 'JobName'])

    precision_in_seconds = pd.to_timedelta(precision).total_seconds()

    index_dfs = []
    for job in slurm_df['JobName'].unique().tolist():
        for index_value in index_minute_periods:
            index_df = slurm_df.query("Start <= @index_value & End >= @index_value & JobName=='%s'" % job)
            if index_df.shape[0] == 0:
                index_dfs.append(pd.Series(data=[index_value, index_df.shape[0],
                                                 0.0, 0.0, 0.0, 0.0, job],
                                           index=['Minute', 'NumJobs', 'NCPUS', 'CPULoad', 'ReqMemory', 'MaxMemory', 'JobName']))
                continue
            index_value_as_timestamp = index_value.to_timestamp()
            index_df['DiffStart'] = index_df.apply(lambda x: pd.to_timedelta(0, unit='S')
                                                             if x.StartRaw < index_value_as_timestamp
                                                             else x.StartRaw - index_value_as_timestamp, axis='columns')
            index_df['DiffEnd'] = index_df.apply(lambda x: pd.to_timedelta(0, unit='S')
                                                           if x.EndRaw > index_value_as_timestamp
                                                           else index_value_as_timestamp - x.EndRaw, axis='columns')
            index_df['Prop'] = index_df.apply(lambda x: (precision_in_seconds - x.DiffStart.total_seconds()
                                                         - x.DiffEnd.total_seconds()) / precision_in_seconds,
                                              axis='columns')
            try:
                index_series = pd.Series(data=[index_value, index_df.shape[0],
                                               index_df['NCPUS'].dot(index_df['Prop']),
                                               index_df['CPULoad'].dot(index_df['Prop']),
                                               index_df['ReqMemInt'].dot(index_df['Prop']),
                                               index_df['MaxRSSInt'].dot(index_df['Prop']),
                                               job],
                                         index=['Minute', 'NumJobs', 'NCPUS', 'CPULoad', 'ReqMemory', 'MaxMemory',
                                            'JobName'])
            except TypeError:
                print(index_df)
            index_dfs.append(index_series)

    minute_dfs = pd.concat(index_dfs, axis='columns').transpose()

    # Resplit minute_dfs into jobs and split out CPUS and memory
    job_types = minute_dfs['JobName'].unique().tolist()
    job_type_dfs = {}

    for job_type in job_types:
        # Get just those job_types with query.
        # Set the index to the submission type to represent the x axis.
        job_type_dfs[job_type] = minute_dfs.set_index("Minute"). \
            query("JobName=='%s'" % job_type). \
            reindex(index_minute_periods). \
            rename(columns={"JobName": job_type,
                            "ReqMemory": "ReqMemory_%s" % job_type,
                            'MaxMemory': "MaxMemory_%s" % job_type,
                            'CPULoad': "CPULoad_%s" % job_type,
                            "NCPUS": "NCPUS_%s" % job_type,
                            "NumJobs": "NumJobs_%s" % job_type}). \
            drop(columns=[job_type])

    # Reconcatenate dataframes based on minute value
    job_types_df = pd.concat(list(job_type_dfs.values()), sort=False, axis='columns').reset_index()

    # Calculate the elapsed time, which can be used by stack-plot on the x-axis
    job_types_df['Elapsed'] = job_types_df['Minute'].dt.to_timestamp() - slurm_df['Submit'].min().to_timestamp()

    return job_types_df


def get_wait_df(slurm_df, precision):
    index_minute_periods = pd.period_range(start=slurm_df['Submit'].min(), end=slurm_df['End'].max(),
                                           freq=precision).tolist()

    precision_in_seconds = pd.to_timedelta(precision).total_seconds()

    index_dfs = []
    for index_value in index_minute_periods: 
        index_df = slurm_df.query("Submit <= @index_value & Start >= @index_value")
        if index_df.shape[0] == 0:
            index_dfs.append(pd.Series(data=[index_value, index_df.shape[0],
                                             0.0, 0.0],
                                       index=['Minute', 'NumJobs', 'NCPUS', 'ReqMemory']))
            continue
        index_value_as_timestamp = index_value.to_timestamp()
        index_df['DiffStart'] = index_df.apply(lambda x: pd.to_timedelta(0, unit='S')
                                                         if x.SubmitRaw < index_value_as_timestamp
                                                         else x.SubmitRaw - index_value_as_timestamp,
                                               axis='columns')
        index_df['DiffEnd'] = index_df.apply(lambda x: pd.to_timedelta(0, unit='S')
                                                       if x.StartRaw > index_value_as_timestamp
                                                       else index_value_as_timestamp - x.StartRaw,
                                             axis='columns')
        index_df['Prop'] = index_df.apply(lambda x: (precision_in_seconds - x.DiffStart.total_seconds() -
                                                     x.DiffEnd.total_seconds()) / precision_in_seconds,
                                          axis='columns')
        index_series = pd.Series(data=[index_value, index_df.shape[0],
                                       index_df['NCPUS'].dot(index_df['Prop']),
                                       index_df['ReqMemInt'].dot(index_df['Prop'])
                                       ],
                                 index=['Minute', 'NumJobs', 'NCPUS', 'ReqMemory'])
        index_dfs.append(index_series)

    minute_dfs = pd.concat(index_dfs, axis='columns').transpose()
    minute_dfs['Minute'] = minute_dfs['Minute'].apply(lambda x: x.to_timestamp())
    minute_dfs['Elapsed'] = minute_dfs['Minute'] - slurm_df['Submit'].min().to_timestamp()

    return minute_dfs


def plot_jobs(job_types_df, output_prefix, job_type, wckey, wait_df): 
    fig, ax = plt.subplots(1, 2)
    fig.suptitle('Resources Used for %s pipeline %s' % (job_type, wckey))
    fig.set_size_inches(20, 10)

    plt.figtext(x=0.5, y=0.04, s="(Shaded=MaxRSS/TotalCPU, Unshaded=Allocated)     Black line shows allocation of waiting jobs'",
                horizontalalignment='center')

    # Plot memory and CPUS
    ax[0].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="NCPUS_").fillna(0).transpose(),
                    colors=my_rbg)
    ax[0].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="CPULoad_").fillna(0).transpose(),
                    colors=my_rbg, alpha=0.5,
                    hatch='//')
    # Plot memory and req memory
    ax[1].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="ReqMemory_").fillna(0).transpose(),
                    colors=my_rbg)
    ax[1].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="MaxMemory_").fillna(0).transpose(),
                    colors=my_rbg, alpha=0.5,
                    hatch='//')

    # Set titles
    ax[0].set_title("CPU Resources Over Time")
    ax[1].set_title("Memory Resources overtime")

    # Remove xlabel
    ax[0].set_xlabel('Time (HH:MM)', fontsize=10)
    ax[1].set_xlabel('Time (HH:MM)', fontsize=10)

    # Set the x and y limits
    ax[0].set_ylim(0, total_cpus)
    ax[1].set_ylim(0, total_memory)

    # Set legend
    ax[0].legend(list(map(lambda x: re.sub("NCPUS_", "", x),
                          job_types_df.filter(like="NCPUS_").columns)));
    ax[1].legend(list(map(lambda x: re.sub("(Max|Req)Memory_", "", x),
                          job_types_df.filter(like="MaxMemory_").columns)));

    # Add in the CPUS wait time for jobs.
    ax[0].plot(wait_df['Elapsed'].apply(lambda x: x.total_seconds()),
               wait_df['NCPUS'].fillna(0), color='black', linestyle='-')
    ax[1].plot(wait_df['Elapsed'].apply(lambda x: x.total_seconds()),
               wait_df['ReqMemory'].fillna(0), color='black', linestyle='-')


    # Set the time values as human friendly
    ax[0].xaxis.set_major_formatter(FuncFormatter(convert_seconds_to_hh_mm_formatter))
    ax[1].xaxis.set_major_formatter(FuncFormatter(convert_seconds_to_hh_mm_formatter))

    # Make the Memory Requirements human Friendly
    ax[1].yaxis.set_major_formatter(FuncFormatter(convert_int_to_human_formatter))

    # Squish everything up nicely
    # fig.tight_layout()

    # Give the top title a bit of room
    fig.subplots_adjust(top=0.9)

    # Save figure
    fig.savefig(output_prefix + '.utilsation.stackplot.png')


def get_stats(slurm_df, job_types_df):
    """
    Grab statistics about utilisations
    :param slurm_df:
    :param job_types_df:
    :return:
    """
    # Initialise stats
    stats = {}

    # Average wait time
    stats['MeanWaitTime'] = slurm_df['WaitTime'].apply(lambda x: x.total_seconds()).mean()
    stats['MedianWaitTime'] = slurm_df['WaitTime'].apply(lambda x: x.total_seconds()).median()
    stats['MaxWaitTime'] = slurm_df['WaitTime'].apply(lambda x: x.total_seconds()).max()

    # CPU allocations
    stats['MeanCPUAllocation'] = job_types_df.filter(like='NCPUS_').apply(max, axis='columns').mean()
    stats['MedianCPUAllocation'] = job_types_df.filter(like='NCPUS_').apply(max, axis='columns').median()
    stats['MaxCPUAllocation'] = job_types_df.filter(like='NCPUS_').apply(max, axis='columns').max()

    # CPU Usages
    stats['MeanCPUUsage'] = job_types_df.filter(like='CPULoad_').apply(max, axis='columns').mean()
    stats['MedianCPUUsage'] = job_types_df.filter(like='CPULoad_').apply(max, axis='columns').median()
    stats['MaxCPUUsage'] = job_types_df.filter(like='CPULoad_').apply(max, axis='columns').max()

    # Mem allocations
    stats['MeanMemAllocation'] = job_types_df.filter(like='ReqMemory_').apply(max, axis='columns').mean()
    stats['MedianMemAllocation'] = job_types_df.filter(like='ReqMemory_').apply(max, axis='columns').median()
    stats['MaxMemAllocation'] = job_types_df.filter(like='ReqMemory_').apply(max, axis='columns').max()

    # Mem Usages
    stats['MeanMemUsage'] = job_types_df.filter(like='MaxMemory_').apply(max, axis='columns').mean()
    stats['MedianMemUsage'] = job_types_df.filter(like='MaxMemory_').apply(max, axis='columns').median()
    stats['MaxMemUsage'] = job_types_df.filter(like='MaxMemory_').apply(max, axis='columns').max()

    # Convert to percentages of total resources
    # CPU allocations
    stats['MeanCPUAllocationPCT'] = 100 * stats['MeanCPUAllocation'] / total_cpus
    stats['MedianCPUAllocationPCT'] = 100 * stats['MedianCPUAllocation'] / total_cpus
    stats['MaxCPUAllocationPCT'] = 100 * stats['MaxCPUAllocation'] / total_cpus

    # CPU Usages
    stats['MeanCPUUsagePCT'] = 100 * stats['MeanCPUUsage'] / total_cpus
    stats['MedianCPUUsagePCT'] = 100 * stats['MedianCPUUsage'] / total_cpus
    stats['MaxCPUUsagePCT'] = 100 * stats['MaxCPUUsage'] / total_cpus

    # Mem allocations
    stats['MeanMemAllocationPCT'] = 100 * stats['MeanMemAllocation'] / total_memory
    stats['MedianMemAllocationPCT'] = 100 * stats['MedianMemAllocation'] / total_memory
    stats['MaxMemAllocationPCT'] = 100 * stats['MaxMemAllocation'] / total_memory

    # Mem Usages
    stats['MeanMemUsagePCT'] = 100 * stats['MeanMemUsage'] / total_memory
    stats['MedianMemUsagePCT'] = 100 * stats['MedianMemUsage'] / total_memory
    stats['MaxMemUsagePCT'] = 100 * stats['MaxMemUsage'] / total_memory

    # Complete stats by jobs
    for job_type in slurm_df['JobName'].unique().tolist(): 
        stats[job_type] = {}
        stats[job_type]['MaxRSS'] = slurm_df.query("JobName=='%s'" % job_type)['MaxRSSInt'].max()
        stats[job_type]['MaxCPU'] = slurm_df.query("JobName=='%s'" % job_type)['CPULoad'].max()
        stats[job_type]['MaxTime'] = slurm_df.query("JobName=='%s'" % job_type)['Elapsed'].max()
        stats[job_type]['MeanRSS'] = slurm_df.query("JobName=='%s'" % job_type)['MaxRSSInt'].mean()
        stats[job_type]['MeanCPU'] = slurm_df.query("JobName=='%s'" % job_type)['CPULoad'].mean()
        stats[job_type]['MeanTime'] = slurm_df.query("JobName=='%s'" % job_type)['Elapsed'].mean()
        stats[job_type]['MedianRSS'] = slurm_df.query("JobName=='%s'" % job_type)['MaxRSSInt'].median()
        stats[job_type]['MedianCPU'] = slurm_df.query("JobName=='%s'" % job_type)['CPULoad'].median()
        stats[job_type]['MedianTime'] = slurm_df.query("JobName=='%s'" % job_type)['Elapsed'].median()

    return stats


# Def main
def main():
    # Grab arguments from CLI
    args = get_args()

    # Grab jobs as a pandas dataframe
    jobs_df = get_jobs(wckey=args.wckey, jobs=args.jobs, precision=args.precision, user=args.user)

    # Adjust names
    if args.job_type == 'demux':
        jobs_df = adjust_demux_job_names(jobs_df)
    elif args.job_type == 'exome':
        jobs_df = adjust_exome_job_names(jobs_df)
    else:
        # No job_type specified.
        pass

    # Adjust names from split
    if args.sep_to_split == '-':
        jobs_df['JobName'] = jobs_df['JobName'].apply(lambda x: x.split("-", 1)[0])
    elif args.sep_to_split == '_':
        jobs_df['JobName'] = jobs_df['JobName'].apply(lambda x: x.split("_", 1)[0])
    elif args.sep_to_split == 'r-':
        jobs_df['JobName'] = jobs_df['JobName'].apply(lambda x: x.rsplit("-", 1)[-1])
    elif args.sep_to_split == 'r_':
        jobs_df['JobName'] = jobs_df['JobName'].apply(lambda x: x.rsplit("-", 1)[-1])
    else:
        # No changes
        pass
    # Drop 'batch' from the name
    jobs_df['JobName'] = jobs_df['JobName'].apply(lambda x: re.sub("_batch$", "", x))

    print(args.sep_to_split)
    print(jobs_df['JobName'])


    # Grab jobs split by job type and minute
    minute_dfs = get_minute_dfs(slurm_df=jobs_df, precision=args.precision)

    # Get waiting df
    wait_df = get_wait_df(slurm_df=jobs_df, precision=args.precision)

    # Grab jobs plot
    plot_jobs(minute_dfs, output_prefix=args.output_prefix, job_type=args.job_type, wckey=args.wckey, wait_df=wait_df)

    # Get stats
    stats = get_stats(jobs_df, minute_dfs)
    print(stats)

    # To pickle
    with open(args.output_prefix + ".pickle", 'wb') as pickle_h:
        all_data = {'slurm_df': jobs_df,
                    'minute_df': minute_dfs,
                    'stats': stats}
        pickle.dump(all_data, pickle_h, protocol=2)
    

# Run the main script
if __name__ == '__main__':
    main()
