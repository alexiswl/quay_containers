#!/usr/bin/env python3
import tempfile
import subprocess
import pandas as pd
import shlex
import sys
import shutil
import numpy as np
import fileinput
# For widget stuff
from ipywidgets import FloatProgress
from IPython.display import display
import time
import re

# Prevent SettingWithCopy warning
pd.options.mode.chained_assignment = None  # default='warn'

LINE_BREAK = '\\\n\t'


class Module:
    """
    Takes in a tuple of module/module.version.
    Checks the module exists.
    Places module load command in batch script.
    """
    def __init__(self, module, check=True, module_version=None):
        self.module = module
        # Add version if present
        if module_version is not None:
            self.module += '/' + module_version
        # Ensure that the module exists in the path
        if check:
            # module is a bash function so must be run through shell.
            module_list = subprocess.run("modulecmd bash avail -t", shell=True,
                                         stderr=subprocess.PIPE)
            modules = module_list.stderr.decode().split("\n")
            if module_version is None and "/" not in self.module:
                modules = [module.split("/")[0] for module in modules]
            if self.module not in modules:
                sys.exit("Error, module %s not available" % self.module)

    def load_module(self):
        return Command(["module", "load", self.module]).as_string


def quote_arg(argument):
    if argument == LINE_BREAK:
        return LINE_BREAK
    else:
        return shlex.quote(argument)


class Command:
    """
    Takes in a list of arguments, each are shlexed and appended to a string.
    Stdout and stderr are optional arguments
    """
    def __init__(self, argument_list, stdout=None, stderr=None, kill_job_on_fail=False, shell=False):
        """
        Get a list of arguments from a given command.
        Shlex them.
        Create a string of arguments.
        """
        self.argument_list = argument_list
        self.stdout = stdout
        self.stderr = stderr
        self.shell = shell
        self.kill_job_on_fail = kill_job_on_fail
        # Generate command
        self.as_string = self.shlex_command()

    def shlex_command(self):
        """Run each argument through shlex"""
        if not self.shell:
            command_string = ' '.join([quote_arg(argument)
                                       for argument in self.argument_list])
        else:
            command_string = ' '.join(self.argument_list)
        # Append stderr to stdout if they're the same
        if self.stdout is not None and self.stderr is not None and self.stderr == self.stdout:
            command_string += " 2>&1 %s" % self.stdout
        # Write stdout only
        if self.stdout is not None and self.stderr is None:
            command_string += " 1> %s" % self.stdout
        # Write stderr only
        if self.stdout is None and self.stderr is not None:
            command_string += " 2> %s" % self.stderr
        # Write to separate files
        if self.stderr is not None and self.stdout is not None and self.stderr != self.stdout:
            command_string += " 2> %s 1> %s" % (self.stderr, self.stdout)

        # Append exit on fail
        if self.kill_job_on_fail:
            command_string += ' || exit 1'

        # Otherwise do nothing!
        return command_string

    def bash_pipe(self, command, stderr=False):
        """
        Pipe stdout into command.
        """
        if stderr:
            self.as_string += " 2>&1 >/dev/null | %s" % command.as_string
        else:
            self.as_string += " | %s" % command.as_string

    def bash_or(self, command):
        """
        Run command if non zero exit code of this command
        """
        self.as_string += " || %s" % command.as_string

    def bash_and(self, command):
        """
        Run command only if zero exit code of this command
        """
        self.as_string += " && %s" % command.as_string


class Job:
    def __init__(self, commands_or_keys, slurm_args, modules=None, template=None):
        """
        Initialise job, write batch to tmp file, or use a template and export environment variables.

        """
        self.job_type = None
        if type(commands_or_keys) == Command and template is None:
            self.commands = [commands_or_keys]
            self.job_type = "command"
        if type(commands_or_keys) == list and template is None:
            self.commands = commands_or_keys
            self.job_type = "command"
        elif type(commands_or_keys) == dict and template is not None:
            self.dict = commands_or_keys
            self.job_type = "keys"
        else:
            sys.exit("Error, either commands as list of class Command or template with keys")
        self.args = slurm_args
        # Modules, a list of tuples
        # [("bowtie"), ("trim_galore", "0.4.5")] etc.
        if modules is None:
            self.modules = None
        elif type(modules) == list:
            self.modules = [Module(module[0], check=True, module_version=module[1])
                            if type(module) == tuple
                            else Module(module, check=True, module_version=None)
                            for module in modules
                           ]
        elif type(modules) == tuple:
            self.modules = [Module(modules[0], check=True, module_version=modules[1])]
        elif type(modules) == str:
            self.modules = [Module(modules, check=True, module_version=None)]
        else:
            self.modules = None
        self.template = template
        if "job-name" in slurm_args.keys():
            prefix = slurm_args["job-name"]
        else:
            prefix = None
        self.batch_file = tempfile.NamedTemporaryFile(prefix=prefix+"_")
        self.batch_out = None
        self.batch_err = None
        self.batch_returncode = None
        self.status = None
        self.id = 0
        # Write batch to tmp file
        if self.job_type == "keys":
            # Copy template over to file first.
            shutil.copy(template, self.batch_file.file)
            # Add any slurm_i arguments listed that have not yet been set in the template.
            option_list = ["#SBATCH --%s=" % key for key in self.args.keys()]
            # Filter out all arguments that have already been set.
            with fileinput.FileInput(self.batch_file.name, inplace=True) as batch_h:
                print_remaining_options = True
                for line in batch_h:
                    # Have we gone past the list of #SBATCH lines
                    if not line.startswith("#SBATCH") and not line.startswith("#!"):
                        # First time this happens we need to print out all the remaining options
                        if print_remaining_options:
                            line = '\n'.join(["#SBATCH --%s=%s" % (key, value)
                                              for key, value in self.args.items()])
                            print_remaining_options = False
                    else:
                        # If not find if the option has already been set.
                        found = False
                        # Overwrite said option
                        for key, value in self.args.keys():
                            if line.startswith("#SBATCH --%s=" % key):
                                line = "#SBATCH --%s=%s" % (key, str(value))
                                del self.args.keys[key]
                                break
                    print(line)
        else:
            with open(self.batch_file.name, 'w') as batch_h:
                # For each of the slurm_i arguments, write to sbatch
                batch_h.write("#!/bin/bash\n")
                batch_h.write("## Setting sbatch commands##\n")
                for key, value in self.args.items():
                    batch_h.write("#SBATCH --%s=%s\n" % (key, value))
                # Add modules in next
                if self.modules is not None:
                    batch_h.write("## Loading modules ##\n")
                    for module in self.modules:
                        batch_h.write(module.load_module() + "\n")
                # Write each of the commands to file
                batch_h.write("## Adding commands ##\n")
                for command in self.commands:
                    batch_h.write(command.as_string + "\n")

    def submit_job(self, extra_args=None):
        """
        Run subprocess using sbatch followed by the tmp filename
        Extra args used for dependency chain in run-jobs
        """
        if self.job_type == "command":
            batch_command = ["sbatch", "--parsable"]
            if extra_args is not None:
                for key, value in extra_args.items():
                    batch_command.append("--%s=%s" % (key, value))
            batch_command.append(self.batch_file.name)
            batch_proc = subprocess.run(batch_command,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:  # key based (use export)
            export_list = ','.join(key + "=" + value for key, value in self.dict.items())
            batch_command = ["sbatch", "--parsable", "--export=%s,ALL" % export_list]
            if extra_args is not None:
                for key, value in extra_args.items():
                    batch_command.append("--%s=%s" % (key, value))
            batch_command.append(self.batch_file.name)
            batch_proc = subprocess.run(batch_command,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.batch_out = batch_proc.stdout.decode()
        self.batch_err = batch_proc.stderr.decode()
        self.batch_returncode = batch_proc.returncode
        # Get job id.
        self.id = int(self.batch_out.split(".")[0].strip())
        # Reprocess stdout and stderr logs.
        # %j becomes the job id
        if "output" in self.args.keys():
            self.args['output'] = re.sub("%j", str(self.id), self.args['output'])
        if "error" in self.args.keys():
            self.args['error'] = re.sub("%j", str(self.id), self.args['error'])

    def get_job_status(self):
        """
        Run sacct on a given job
        """
        self.update_job_status()
        return self.status

    def update_job_status(self):
        self.status = slurm_to_pd(self, vanilla=True).State.item()

    def __str__(self):
        with open(self.batch_file.name, 'r') as batch_h:
            '\n'.join(batch_h.readlines())

    def show_batch_script(self):
        output_lines = []
        with open(self.batch_file.name, 'r') as batch_h:
            for line in batch_h.readlines():
                if line.startswith("##"):
                    output_lines.append("\n%s" % line.strip())
                else:
                    # Rstrip so tabs remain in place
                    output_lines.append("%s" % line.rstrip())
        line_list = '\n'.join(output_lines)
        print("""%s""" % line_list)


def slurm_to_pd(jobs, columns=None, vanilla=False):
    """
    Given a list of jobs return a pandas data frame of their status
    """

    #standard_columns = ['JobID', 'JobName', 'Timelimit', 'ReqMem', 'State', 'ExitCode', 'Submit']
    standard_columns = ['JobID', 'JobIDRaw', 'JobName', 'ReqMem', 'NCPUS', 'MaxRSS',
                        'Timelimit', 'Elapsed', 'Submit', 'Start', 'End', 'State',
                        'TotalCPU', 'SystemCPU', 'CPUTimeRAW', 'wckey', 'NodeList', 'NNodes']

    if columns is None:
        columns = standard_columns.copy()
    elif type(columns) == str:
        columns = [columns]
        columns.extend(standard_columns.copy())
    else:
        columns = list(set(columns).union(set(standard_columns)))

    attempt_counter = 0
    while True:
        try:
            sacct_command = ["sacct", "--parsable2",
                             "--jobs=%s" % ','.join([str(job.id) for job in jobs if not job.id == 0]),
                             "--format=%s" % ','.join(columns)]
            if vanilla:
                # Add in --allocations so we just get the job (not the steps)
                sacct_command.append("--allocations")
            sacct_proc = subprocess.run(sacct_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                        timeout=20)
            break
        except subprocess.TimeoutExpired:
            time.sleep(15)
            attempt_counter += 1
        if attempt_counter > 3:
            sys.exit("Error, continued timeout of sacct")
    sacct_returncode = sacct_proc.returncode
    sacct_stdout = sacct_proc.stdout.decode()
    sacct_stderr = sacct_proc.stderr.decode()
    # Return a list of sacct_stdout.
    columns = sacct_stdout.split("\n")[0].strip().split("|")
    rows_of_jobs = [row.strip().split("|") for row in sacct_stdout.split("\n")[1:-1]]
    # Read as a dataframe
    df = pd.DataFrame(rows_of_jobs, columns=columns)
    if vanilla:
        return df
    # Get sbatch job for JobName and JObID.
    df_bulk = df.query("JobID.str.contains(r'^\d+$') & ~JobID.str.contains('batch')")
    df_srun = df.query("JobID.str.contains(r'^\d+\.\d+$') | JobID.str.contains('batch')")
    # No srun jobs in sbatch
    if df_srun.shape[0] == 0:
        return df
    # Now split, drop required columns and rejoin
    # We just want the name from the bulk columns
    bulk_items = ['JobID', 'JobIDRaw', 'JobName', 'Timelimit', 'Submit']
    df_bulk = df_bulk.filter(items=bulk_items)
    # Everything else from the srun column
    df_srun['JobIDRaw'] = df_srun.apply(lambda x: re.sub("\.(\d+|batch)$", "", x.JobIDRaw), axis='columns')
    df_srun.drop(columns=['Timelimit', 'Submit', 'JobID'], inplace=True)
    
    # Remove batch from srun component
    df_srun.query("~(JobName=='batch')", inplace=True)

    df = pd.merge(df_bulk, df_srun, on='JobIDRaw', suffixes=("_bulk", "_srun"), how='left')
    # Merge the job names
    df['JobName'] = df.apply(lambda x: '_'.join(map(str, [x.JobName_bulk, x.JobName_srun])), axis='columns')
    # Get the job ID
    df['JobID'] = df['JobIDRaw']
    # Drop existing batch and srun columns
    df.drop(["JobName_bulk", "JobName_srun"], axis='columns', inplace=True)
    return df


def run_jobs(jobs, restrict=0, randomise=True, wait=False):
    if restrict == 0:
        [job.submit_job() for job in jobs]
    else:
        # Randomise job list first.
        # Reduces likelihood of job buildup.
        if randomise:
            np.random.shuffle(jobs)
        # Slice job lists. Wait for each job to complete before moving onto next job.
        jobs_split = np.array_split(jobs, restrict)
        for job_list in jobs_split:
            # First job in each list can be kicked off without waiting
            job_id = 0
            for job in job_list:
                if not job_id == 0:
                    # At least second time through
                    job.submit_job(extra_args={"dependency": "afterany:%d" % job_id})
                if job_id == 0:
                    # First time through,
                    # Submit job with no conditions
                    job.submit_job()
                # Assign id var to carry through as dependency to next job in list
                job_id = job.id
    if wait:
        time.sleep(10)
        df = slurm_to_pd(jobs, vanilla=True)
        while not all_complete(df):
                time.sleep(10)
                df = slurm_to_pd(jobs, vanilla=True)


def all_complete(job_df):
    """
    Given a job data frame, determine if all jobs have finished.
    Even if they have failed or cancelled.
    """
    wait_list = ['PENDING', "RUNNING", "REQUEUED"]
    complete_list = ['FAILED', "COMPLETED"]
    num_jobs_waiting = len(job_df.query("State in @wait_list").index)
    num_jobs_complete = len(job_df.query("State in @complete_list").index)

    if len(job_df.index) == 0:
        time.sleep(15)
        # Don't set as complete.
        return False

    if num_jobs_waiting + num_jobs_complete != len(job_df.index):
        print([state for state in job_df['State'].unique().tolist()
               if state not in wait_list
               and state not in complete_list])

    if num_jobs_waiting == 0:
        return True
    else:
        return False


def show_progress_bar(jobs, hold=True, completed_only=False):
    """
    Given a set of processes, show pass jobs, running, fail/cancelled jobs and waiting jobs.
    """
    completion_bar = FloatProgress(min=0, max=len(jobs), value=0,
                                   description="COMPLETED", bar_style="success")
    display(completion_bar)
    if not completed_only:
        fail_bar = FloatProgress(min=0, max=len(jobs), value=0,
                                 description="FAIL/CANCEL", bar_style="danger")
        pending_bar = FloatProgress(min=0, max=len(jobs), value=0,
                                    description="PENDING", bar_style="info")
        running_bar = FloatProgress(min=0, max=len(jobs), value=0,
                                    description="RUNNING", bar_style="warning")
        display(fail_bar)
        display(pending_bar)
        display(running_bar)

    # Takes three seconds for job to be submitted to slurm
    time.sleep(3)

    df = slurm_to_pd(jobs, vanilla=True)
    while not all_complete(df):
        completion_bar.value = len(df.query("State=='COMPLETED'").index)
        fail_bar.value = len(df.query("State=='FAILED' | State=='CANCELLED'").index)
        pending_bar.value = len(df.query("State=='PENDING'").index)
        running_bar.value = len(df.query("State=='RUNNING'").index)
        if not hold:
            break
        else:
            time.sleep(10)
        # Refresh data frame
        df = slurm_to_pd(jobs, vanilla=True)

    completion_bar.value = len(df.query("State=='COMPLETED'").index)
    fail_bar.value = len(df.query("State=='FAILED' | State=='CANCELLED'").index)
    pending_bar.value = len(df.query("State=='PENDING'").index)
    running_bar.value = len(df.query("State=='RUNNING'").index)


def get_post_job_usage(jobs):
    usage_columns = ["JobID", "CPUTime", "ReqMem",
                     "AveRSS", "MaxRSS", "MaxVMSize",
                     "Elapsed"]
    df = slurm_to_pd(jobs, columns=usage_columns)
    return df
