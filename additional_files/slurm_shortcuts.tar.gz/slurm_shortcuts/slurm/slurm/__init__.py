# Import the version
from . import version

# Import the slurm module as the top level
from . import slurm


