import os
import subprocess
from slurm import slurm
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from datetime import datetime
import re
import numpy as np
import seaborn as sns
import humanfriendly
import math
from matplotlib import cm

total_cpus = sum([2*2*18*2, 2*4*10*2, 3*4*16*2, 2*8*2])
total_memory = sum([2*128000, 2*512000, 3*1536000, 2*128000]) * 1000000

def parse_number(value_h):
    return int(re.match("^(\d+)\S+$", value_h).group(1))

def convert_human_to_int(value_h):
    if value_h.endswith("G"):
        value = parse_number(value_h) * 1000000000
    elif value_h.endswith("M"):
        value = parse_number(value_h) * 1000000
    elif value_h.endswith("K"):
        value = parse_number(value_h) * 1000
    elif value_h == "":
        value = 0
    else:
        value = int(value_h)
    return int(value)

def convert_reqmem_to_int(value_h, ncpus):
    if value_h.endswith("Gc"):
        value = parse_number(value_h) * 1000000000
    elif value_h.endswith("Mc"):
        value = parse_number(value_h) * 1000000
    elif value_h.endswith("Kc"):
        value = parse_number(value_h) * 1000
    else:
        value = int(value_h)
    return int(value) * ncpus

def convert_int_to_human_formatter(value, pos):
    return(humanfriendly.format_size(value).replace("bytes", ""))

def convert_seconds_to_hh_mm_formatter(value, pos):
    hours = math.floor(value / 3600)
    minutes = (value - 3600 * hours) / 60
    return "%02d:%02d" % (hours, minutes)

class Job():
    def __init__(self, slurm_id):
        self.id = slurm_id

# CMAP needs to be converted to RBG code to work
def int_to_hex(my_int):
    return format(int(255*my_int), '02x')
def colours_to_rgb(red, blue, green):
    return '#%s%s%s' % (int_to_hex(red), int_to_hex(blue), int_to_hex(green))

def parse_number(value_h):
    return int(re.match("^(\d+)\S+$", value_h).group(1))

def convert_human_to_int(value_h):
    if value_h.endswith("G"):
        value = parse_number(value_h) * 1000000000
    elif value_h.endswith("M"):
        value = parse_number(value_h) * 1000000
    elif value_h.endswith("K"):
        value = parse_number(value_h) * 1000
    elif value_h == "":
        value = 0
    else:
        value = int(value_h)
    return int(value)

def convert_reqmem_to_int(value_h, ncpus):
    if value_h.endswith("Gc"):
        value = parse_number(value_h) * 1000000000
    elif value_h.endswith("Mc"):
        value = parse_number(value_h) * 1000000
    elif value_h.endswith("Kc"):
        value = parse_number(value_h) * 1000
    else:
        value = int(value_h)
    return int(value) * ncpus

def convert_int_to_human_formatter(value, pos):
    return(humanfriendly.format_size(value).replace("bytes", ""))

def convert_seconds_to_hh_mm_formatter(value, pos):
    hours = math.floor(value / 3600)
    minutes = (value - 3600 * hours) / 60
    return "%02d:%02d" % (hours, minutes)


def grab_jobs_df(jobs_list):
    slurm_df = slurm.slurm_to_pd([Job(x) for x in jobs_list],
                                 columns=['JobID', 'JobName', 'ReqMem', 'NCPUS', 'MaxRSS',
                                          'Timelimit', 'Elapsed', 'Submit', 'Start', 'End',
                                          'TotalCPU', 'CPUTimeRaw'])

    # Rename TotalCPU to TotalCPURAW so it may be re-run without issue
    slurm_df.rename(columns={'TotalCPU': 'TotalCPURAW'},
                    inplace=True)

    # Reset job column types
    slurm_df['JobID'] = pd.to_numeric(slurm_df['JobID'])
    slurm_df['Submit'] = pd.to_datetime(slurm_df['Submit'])
    slurm_df['Start'] = pd.to_datetime(slurm_df['Start'])
    slurm_df['End'] = pd.to_datetime(slurm_df['End'], errors='coerce')
    # Remove Running Jobs
    slurm_df.dropna(inplace=True)
    slurm_df['NCPUS'] = pd.to_numeric(slurm_df['NCPUS'])
    slurm_df['Start'] = slurm_df['Start'].dt.to_period('10min')
    slurm_df['End'] = slurm_df['End'].dt.to_period('10min')

    # Drop batch
    slurm_df.query("~JobName.str.contains('_batch')", inplace=True)

    return slurm_df


def main():
    # Get args
    args = get_args()

    # Get jobs
    jobs = args.jobs.split(",")

    # Get dataframe
    slurm_df = grab_jobs_df()

    # Rename jobs
    slurm_df['JobName'] = slurm_df['JobName'].apply(lambda x: x.split("_", 1)[0])

    # Get Memory from ReqMem and MaxRSS
    slurm_df["ReqMemInt"] = slurm_df[['ReqMem', 'NCPUS']].apply(lambda x: convert_reqmem_to_int(x.ReqMem, x.NCPUS),
                                                                axis='columns')
    slurm_df['MaxRSSInt'] = slurm_df[['MaxRSS', 'NCPUS']].apply(lambda x: convert_human_to_int(x.MaxRSS),
                                                                axis='columns')

    # Get CPUload value
    slurm_df["TotalCPU"] = slurm_df.apply(
        lambda x: x.TotalCPURAW if len(x.TotalCPURAW.split(".")) == 1 else "00:" + x.TotalCPURAW.split(".")[0],
        axis='columns')
    slurm_df["TotalCPU"] = pd.to_timedelta(slurm_df["TotalCPU"])
    slurm_df["CPUTime"] = pd.to_timedelta(slurm_df["CPUTimeRAW"].apply(lambda x: "%ss" % x))
    slurm_df["CPULoad"] = slurm_df.apply(
        lambda x: x.NCPUS * x.TotalCPU.total_seconds() / (x.CPUTime.total_seconds() + 1), axis='columns')

    index_minute_periods = pd.period_range(start=slurm_df['Start'].min(), end=pd.to_datetime("2018-12-21"),
                                           freq='10min').tolist()
    minute_dfs = pd.DataFrame(data=None,
                              columns=['Minute', 'NumJobs', 'NCPUS', 'CPULoad', 'ReqMemory', 'MaxMemory', 'JobName'])

    index_dfs = []
    for job in log_progress(slurm_df['JobName'].unique().tolist(), every=1):
        for index_value in index_minute_periods:
            index_df = slurm_df.query("Start <= @index_value & End >= @index_value & JobName=='%s'" % job)
            index_series = pd.Series(data=[index_value, index_df.shape[0],
                                           index_df['NCPUS'].sum(),
                                           index_df['CPULoad'].sum(),
                                           index_df['ReqMemInt'].sum(), index_df['MaxRSSInt'].sum(),
                                           job],
                                     index=['Minute', 'NumJobs', 'NCPUS', 'CPULoad', 'ReqMemory', 'MaxMemory',
                                            'JobName'])
            index_dfs.append(index_series)


    minute_dfs = pd.concat(index_dfs, axis='columns').transpose()

    # Resplit minute_dfs into jobs and split out CPUS and memory
    job_types = minute_dfs['JobName'].unique().tolist()
    job_type_dfs = {}

    for job_type in job_types:
        # Get just those job_types with query.
        # Set the index to the submission type to represent the x axis.
        job_type_dfs[job_type] = minute_dfs.set_index("Minute"). \
            query("JobName=='%s'" % job_type). \
            reindex(index_minute_periods). \
            rename(columns={"JobName": job_type,
                            "ReqMemory": "ReqMemory_%s" % job_type,
                            'MaxMemory': "MaxMemory_%s" % job_type,
                            'CPULoad': "CPULoad_%s" % job_type,
                            "NCPUS": "NCPUS_%s" % job_type,
                            "NumJobs": "NumJobs_%s" % job_type}). \
            drop(columns=[job_type])

    # Reconcatenate dataframes based on minute value
    job_types_df = pd.concat(list(job_type_dfs.values()), sort=False, axis='columns').reset_index()
    # Calculate the elapsed time, which can be used by stack-plot on the x-axis
    job_types_df['Elapsed'] = job_types_df['Minute'].dt.to_timestamp() - slurm_df['Start'].min().to_timestamp()

    # Get enough colours to plot on both shaded and unshaded
    colours = list(plt.cm.tab10.colors)  # + list(reversed(plt.cm.Set3.colors))
    my_rbg = [colours_to_rgb(*colour) for colour in colours]

    fig, ax = plt.subplots(1, 2)
    fig.suptitle('Resources Used for Exome AGRF16-00215')
    fig.set_size_inches(20, 10)

    plt.figtext(x=0.5, y=0, s="3 samples, (Shaded=MaxRSS/TotalCPU, Unshaded=Allocated)",
                horizontalalignment='center')

    # Plot memory and CPUS
    ax[0].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="NCPUS_").fillna(0).transpose(),
                    colors=my_rbg)
    ax[0].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="CPULoad_").fillna(0).transpose(),
                    colors=my_rbg, alpha=0.5,
                    hatch='//')
    # Plot memory and req memory
    ax[1].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="ReqMemory_").fillna(0).transpose(),
                    colors=my_rbg)
    ax[1].stackplot(job_types_df['Elapsed'].apply(lambda x: x.total_seconds()),
                    job_types_df.filter(like="MaxMemory_").fillna(0).transpose(),
                    colors=my_rbg, alpha=0.5,
                    hatch='//')

    # Set titles
    ax[0].set_title("CPU Resources Over Time")
    ax[1].set_title("Memory Resources overtime")

    # Remove xlabel
    ax[0].set_xlabel('Time (HH:MM)', fontsize=10)
    ax[1].set_xlabel('Time (HH:MM)', fontsize=10)

    # Set the x and y limits
    ax[0].set_ylim(0, total_cpus)
    ax[1].set_ylim(0, total_memory)

    # Set legend
    ax[0].legend(list(map(lambda x: re.sub("NCPUS_", "", x), job_types_df.filter(like="NCPUS_").columns)));
    ax[1].legend(
        list(map(lambda x: re.sub("(Max|Req)Memory_", "", x), job_types_df.filter(like="MaxMemory_").columns)));

    # Set the time values as human friendly
    ax[0].xaxis.set_major_formatter(FuncFormatter(convert_seconds_to_hh_mm_formatter))
    ax[1].xaxis.set_major_formatter(FuncFormatter(convert_seconds_to_hh_mm_formatter))

    # Make the Memory Requirements human Friendly
    ax[1].yaxis.set_major_formatter(FuncFormatter(convert_int_to_human_formatter))

    # Squish everything up nicely
    # fig.tight_layout()

    # Give the top title a bit of room
    fig.subplots_adjust(top=0.9)

    # Save figure
    fig.savefig("CAGRF18542_clinical.png")