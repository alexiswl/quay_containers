# Slurm

A small module to handle slurm submission within python.

## Requirements
`python >= 3.5`

## Installation
```
git clone git@github.com:AGRF/slurm_shortcuts.git
cd slurm_shortcuts/slurm
python3 setup.py install
```

## Usage
### Import the subfunction
`from slurm import slurm`

### Create a list of modules and two Command objects
`# Loads modules sleep and tired/3.4 before running commands`  
`modules = [("sleep"), ("tired", "3.4")]`  
`command1 = slurm.Command(["sleep", 3])`  
`command2 = slurm.Command(["tired", "--sleep_min=3", "--sleep_max=5"])`  

### Create a job object
#### Assign a list commands to a job
Must be 'slurm.Command' objects, not just a list of strings.
```
job = slurm.Job([command1, command2],
                 modules = modules,
                 slurm_args = {"mem": "10G"})
```
#### Use a file template instead of a list of commands
Useful if wanting to run if/for loops within the bash template,
or use bash variables through out the script.
These variables will be parsed to sbath using the `--export` parameter.  

```
job = slurm.Job("/path/to/batch_template.sh",
                slurm_args = {"mem": "10G"})
```

#### View job attributes
Each job has a set of attributes.  
`print(job.__dict__)`

### View job batch file
Prior to running, each job is saved to a batch file in the /tmp directory.  
`print(job.batch_file.name)`

### Submit job to cluster
If the batch file looks correct, submit the job to the cluster.  
`job.submit_job()`

### Submit multiple jobs to cluster
Submit all jobs at once.  
`[job.submit_job() for job in jobs];`

### Run a maximum of 12 jobs in parallel.
`slurm.run_jobs(jobs, restrict=12)`  
All jobs will be submitted but will have 12 separate dependency chains.

## Get job status as a pandas data frame
`jobs_df = slurm.slurm_to_pd(jobs)`
### View all running jobs
`jobs_df.query("JobID=='RUNNING'")`
### Get summary of all jobs
`jobs_df.JobID.value_counts()`

### Wait for jobs to complete in a pipeline.
```
import time
while True:
    df = slurm.slurm_to_pd(jobs)
    if (slurm.all_complete(df)):
        break
    else:
        time.sleep(10)
```

### Watch jobs on a jupyter notebook.
```
slurm.show_progress_bar(jobs, hold=True,
                        completed_only=False)
```

![alt_text](./images/show_jobs_example.png)

`hold=True` ensures that the next block is not run until all jobs are complete.

## To do list:
Re-write all of this tutorial in a jupyter notebook.

